/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { Upload } from "lucide-react";

interface Scene {
  time: number;
  subtitle: string;
  text: string;
}

export default function App() {
  // 8 distinct architectural scenes in a single continuous video, mapped at exactly 3-second intervals
  const SCENES: Scene[] = [
    {
      time: 0,
      subtitle: "Scena 01 • Il Sacramento dell'Ingresso",
      text: "Portico monumentale defined by raw concrete setts. Geometry shields the living core, framing the maritime pines during sunset."
    },
    {
      time: 3,
      subtitle: "Scena 02 • Sguardo verso l'Atrio",
      text: "The architectural camera glides horizontally. Expansive glass walls erase boundaries, letting the natural surroundings invade the shelter."
    },
    {
      time: 6,
      subtitle: "Scena 03 • La Corte d'Ombra",
      text: "A direct central patio under a sculpted ceiling. Shadows move with precision as horizontal concrete volumes interlock."
    },
    {
      time: 9,
      subtitle: "Scena 04 • La Linea d'Acqua",
      text: "Beyond the deck, the infinity pool reflects raw sandstone textures, merging sky and water in an endless chromatic sequence."
    },
    {
      time: 12,
      subtitle: "Scena 05 • Il Giardino d'Inverno",
      text: "A micro-oasis designed inside. Minimalist raw stones pair with a single olive tree, bared in pure zenital light."
    },
    {
      time: 15,
      subtitle: "Scena 06 • Il Corridoio Monolitico",
      text: "Asymmetrical travertine walkways cut by vertical slits. The absolute void of decoration creates a sacred, silent experience."
    },
    {
      time: 18,
      subtitle: "Scena 07 • L'Incontro Materico",
      text: "A close study of architectural joints: dark acid-etched brass accents meet deep Belgian oak warmth next to sand-blasted concrete."
    },
    {
      time: 21,
      subtitle: "Scena 08 • Il Soggiorno Sospeso",
      text: "Floating above the landscape via self-supporting steel girders. Pure architectural silence at the journey's peak."
    }
  ];

  const [currentSceneIdx, setCurrentSceneIdx] = useState(0);
  const [customVideoUrl, setCustomVideoUrl] = useState<string | null>(null);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const targetTimeRef = useRef<number>(0);
  const rafRef = useRef<number | null>(null);
  const lastScrollTime = useRef<number>(0);

  // Smooth cinematic transitions and text updates
  const changeScene = (nextIdx: number) => {
    const now = Date.now();
    setIsTransitioning(true);
    setCurrentSceneIdx(nextIdx);
    targetTimeRef.current = SCENES[nextIdx].time;
    lastScrollTime.current = now;
    triggerSmoothTransition();
  };

  // Intercept scroll wheel of any strength.
  useEffect(() => {
    const handleGlobalWheel = (e: WheelEvent) => {
      e.preventDefault();
      
      const now = Date.now();
      // Debounce trigger rate to prevent rapid double-scene skips
      if (now - lastScrollTime.current < 800) return;

      if (e.deltaY > 3) {
        // Scroll Down -> Transition directly to next scene
        if (currentSceneIdx < SCENES.length - 1) {
          changeScene(currentSceneIdx + 1);
        }
      } else if (e.deltaY < -3) {
        // Scroll Up -> Transition directly to previous scene
        if (currentSceneIdx > 0) {
          changeScene(currentSceneIdx - 1);
        }
      }
    };

    const container = containerRef.current;
    if (container) {
      container.addEventListener("wheel", handleGlobalWheel, { passive: false });
    }

    return () => {
      if (container) {
        container.removeEventListener("wheel", handleGlobalWheel);
      }
    };
  }, [currentSceneIdx]);

  // Mobile swipes: swipe up moves down, swipe down moves up
  const touchStartY = useRef<number>(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const deltaY = e.touches[0].clientY - touchStartY.current;
    if (Math.abs(deltaY) < 25) return; // threshold

    const now = Date.now();
    if (now - lastScrollTime.current < 800) return;

    if (deltaY < 0) {
      // Swiped Up (Scroll Down) -> Move forward
      if (currentSceneIdx < SCENES.length - 1) {
        changeScene(currentSceneIdx + 1);
      }
    } else {
      // Swiped Down (Scroll Up) -> Move backward
      if (currentSceneIdx > 0) {
        changeScene(currentSceneIdx - 1);
      }
    }
  };

  // Easing transition: glides seamlessly through the single continuous video
  const triggerSmoothTransition = () => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
    }

    const step = () => {
      if (videoRef.current) {
        const current = videoRef.current.currentTime;
        const target = targetTimeRef.current;
        const diff = target - current;

        // Custom easing coefficient for absolute high-grade fluid response (0.12)
        if (Math.abs(diff) < 0.01) {
          videoRef.current.currentTime = target;
          rafRef.current = null;
          // Smoothly remove fade-out effect after transition finishes
          setTimeout(() => {
            setIsTransitioning(false);
          }, 150);
        } else {
          videoRef.current.currentTime = current + (diff * 0.12);
          rafRef.current = requestAnimationFrame(step);
        }
      } else {
        rafRef.current = null;
        setIsTransitioning(false);
      }
    };
    rafRef.current = requestAnimationFrame(step);
  };

  const handleCustomUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const originalUrl = URL.createObjectURL(e.target.files[0]);
      setCustomVideoUrl(originalUrl);
      targetTimeRef.current = 0;
      setCurrentSceneIdx(0);
      setIsTransitioning(false);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
      }
    }
  };

  // Preloaded continuous architectural track (will repeat or scale to custom duration)
  const defaultVideoUrl = "https://assets.mixkit.co/videos/preview/mixkit-modern-luxury-exterior-villa-design-41712-large.mp4";

  return (
    <div 
      ref={containerRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      className="relative w-screen h-screen overflow-hidden bg-stone-950 text-stone-100 font-sans flex flex-col justify-between select-none"
      id="villa-omnia-super-minimalist-showcase"
    >
      
      {/* Custom Styles for clean animations */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>

      {/* 1. BACKGROUND CONTINUOUS VIDEO PORT (100% SCREEN COVERAGE) */}
      <div className="absolute inset-0 w-full h-full z-0 pointer-events-none overflow-hidden">
        <video
          ref={videoRef}
          src={customVideoUrl || defaultVideoUrl}
          className="w-full h-full object-cover select-none"
          muted
          playsInline
          loop
        />

        {/* Ambient atmospheric linear gradients */}
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-stone-950 via-stone-950/20 to-transparent pointer-events-none"></div>

        {/* Robust Bottom Darkening Vignette - ensuring high content contrast */}
        <div className="absolute bottom-0 left-0 w-full h-[65%] bg-gradient-to-t from-stone-950 via-stone-950/85 to-transparent pointer-events-none"></div>
      </div>

      {/* 2. HEADER BAR (Ultra Slim, elegant) */}
      <header className="relative z-10 w-full px-6 py-6 md:px-12 md:py-8 flex items-center justify-between pointer-events-auto">
        <div className="flex flex-col">
          <h1 className="text-[11px] md:text-[13px] font-display font-light uppercase tracking-[0.35em] text-white">
            VILLA <span className="font-semibold text-stone-400">OMNIA</span>
          </h1>
          <p className="text-[7px] tracking-[0.4em] uppercase text-stone-500 font-medium mt-0.5">
            Studio Architettura Narrativa
          </p>
        </div>

        {/* Tiny custom video uploader */}
        <label className="text-[7.5px] md:text-[8px] font-mono tracking-widest text-stone-600 hover:text-stone-300 transition duration-300 uppercase cursor-pointer">
          <span>[ carica video continuo ]</span>
          <input 
            type="file" 
            accept="video/*" 
            className="hidden" 
            onChange={handleCustomUpload}
          />
        </label>
      </header>

      {/* 3. CENTERED INTERACTION AREA */}
      <div className="relative z-10 self-center pointer-events-none text-center px-6" />

      {/* 4. THE CORE ESSENTIAL BLOCK (Fully Centered, Responsive Layout) */}
      <section className="relative z-10 w-full max-w-xl mx-auto px-6 pb-12 md:pb-16 flex flex-col items-center text-center gap-4 pointer-events-auto">
        
        <div className="flex flex-col items-center gap-1">
          {/* Elegant scene subtitle */}
          <h2 className="text-sm sm:text-base md:text-lg font-serif font-light text-white italic tracking-wide leading-tight">
            {SCENES[currentSceneIdx].subtitle}
          </h2>
        </div>

        {/* Highly Responsive Text/Button Box */}
        <div className="max-w-md min-h-[44px] md:min-h-[52px] flex items-center justify-center">
          {currentSceneIdx === SCENES.length - 1 ? (
            <button 
              onClick={() => setShowInfoModal(true)}
              className="px-5 py-2.5 border border-white/20 hover:border-white/80 bg-white/5 hover:bg-white text-[9px] text-stone-300 hover:text-stone-950 font-mono uppercase tracking-[0.25em] rounded-full transition-all duration-500 ease-out active:scale-95 animate-fade-in cursor-pointer"
            >
              Scopri di più
            </button>
          ) : (
            <p className="text-[10px] sm:text-[11px] md:text-[12px] text-stone-300 font-light leading-relaxed tracking-wide transition-all duration-300 ease-out animate-fade-in">
              {SCENES[currentSceneIdx].text}
            </p>
          )}
        </div>

      </section>

      {/* 5. EDITORIAL INFO OVERLAY (Minimalist Layout Modal) */}
      {showInfoModal && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-stone-950/90 backdrop-blur-md animate-fade-in pointer-events-auto">
          <div className="max-w-xs sm:max-w-sm w-full bg-stone-900/60 border border-white/10 p-6 md:p-8 rounded-xl flex flex-col gap-5 text-center relative overflow-hidden">
            
            <div className="flex justify-between items-start pt-2">
              <div className="flex flex-col text-left">
                <span className="text-[8px] font-mono tracking-[0.3em] text-stone-500 uppercase">Progetto Monografico</span>
                <h3 className="text-sm sm:text-base font-serif italic text-white mt-0.5">VILLA OMNIA</h3>
              </div>
              <button 
                onClick={() => setShowInfoModal(false)}
                className="text-[8px] font-mono tracking-widest text-stone-500 hover:text-white transition duration-300 uppercase cursor-pointer"
              >
                [ chiudi ]
              </button>
            </div>

            <div className="border-t border-white/5 my-1" />

            {/* Specifications cleanly laid out */}
            <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-left">
              <div>
                <span className="block text-[7.5px] font-mono tracking-wider text-stone-500 uppercase">Ubicazione</span>
                <span className="text-[10px] text-stone-300 font-light tracking-wide">Costiera Amalfitana, IT</span>
              </div>
              <div>
                <span className="block text-[7.5px] font-mono tracking-wider text-stone-500 uppercase">Anno</span>
                <span className="text-[10px] text-stone-300 font-light tracking-wide">2026</span>
              </div>
              <div>
                <span className="block text-[7.5px] font-mono tracking-wider text-stone-500 uppercase">Superficie</span>
                <span className="text-[10px] text-stone-300 font-light tracking-wide">940 mq</span>
              </div>
              <div>
                <span className="block text-[7.5px] font-mono tracking-wider text-stone-500 uppercase">Architettura</span>
                <span className="text-[10px] text-stone-300 font-light tracking-wide">Omnia Lab</span>
              </div>
            </div>

            <div className="border-t border-white/5 my-1" />

            <div className="text-left">
              <span className="block text-[7.5px] font-mono tracking-wider text-stone-500 uppercase mb-1">Concept Filosofico</span>
              <p className="text-[10px] text-stone-400 font-light leading-relaxed">
                Un'opera monumentale che dissolve la materia tra interno ed esterno. I setti murari in cemento faccia vista dialogano con la luce zenitale, creando un tempio contemporaneo di silenzio e contemplazione.
              </p>
            </div>

            <div className="pt-2 flex justify-center pb-2">
              <button
                onClick={() => setShowInfoModal(false)}
                className="px-5 py-2 bg-stone-100 hover:bg-white text-stone-950 text-[8px] font-mono uppercase tracking-[0.2em] rounded-full transition duration-300 active:scale-95 cursor-pointer font-medium"
              >
                Torna al Movimento
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
